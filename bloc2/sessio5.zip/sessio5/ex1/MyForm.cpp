
// MyForm.cpp

// Implementacio de la classe definida a MyForm.h


#include "MyForm.h"

MyForm::MyForm(QWidget* parent) : QWidget(parent)
{
  ui.setupUi(this);
}
